module.exports = function (RED) {
  const { createBluetooth } = require('node-ble')

  /**
   * Main logic for Bluetooth operations
   * @param {string} operation - "write" or "read"
   * @param {number} handle - The decimal representation of the hex handle
   * @param {string} mac - Target device MAC address
   * @param {string} data - Hex string to write (only for write op)
   */
  async function processBluetoothOperation (operation, handle, mac, data) {
    let device
    try {
      const { bluetooth, destroy } = createBluetooth()
      const adapter = await bluetooth.defaultAdapter()

      if (!await adapter.isDiscovering()) {
        await adapter.startDiscovery()
      }

      // Wait for the specific device to be discovered
      device = await adapter.waitDevice(mac)
      await device.connect()
      
      const gattServer = await device.gatt()
      const uuid = await gattServer.getUUIDbyHandle(handle)

      if (uuid !== null) {
        const service = await gattServer.getPrimaryService(uuid.service)
        const characteristic = await service.getCharacteristic(uuid.char)

        let result
        if (operation === 'write') {
          const dataToWrite = Buffer.from(data, 'hex')
          await characteristic.writeValue(dataToWrite)
          // Output to stdout (first output)
          result = [{ payload: 'Write operation successful' }, null, null]
        } else if (operation === 'read') {
          const value = await characteristic.readValue(0)
          // Output: success info on first pin, raw data on third pin
          result = [{ payload: 'Read operation successful' }, null, { payload: value.toString('hex') }]
        } else {
          result = [null, { payload: 'Invalid operation type' }, null]
        }

        // Cleanup and disconnect
        await device.disconnect()
        destroy()

        return result
      } else {
        throw new Error('UUIDs not found for the given handle')
      }
    } catch (error) {
      if (device) {
        await device.disconnect()
      }
      throw new Error('Bluetooth error: ' + error.message)
    }
  }

  function BluetoothNode (config) {
    RED.nodes.createNode(this, config)
    const node = this

    node.on('input', async function (msg) {
      // Hybrid logic: Prioritize msg.payload values, fallback to node configuration
      const operation = msg.payload.operation || config.operation
      const mac = msg.payload.mac || config.mac
      const rawHandle = msg.payload.handle || config.handle
      const data = msg.payload.data || ""

      // Status indicator in Node-RED UI
      node.status({fill: "blue", shape: "dot", text: "connecting..."})

      // Parse handle (supporting both hex string and decimal input)
      let handle = NaN
      if (typeof rawHandle === 'string') {
          handle = parseInt(rawHandle, 16)
      } else {
          handle = rawHandle
      }

      // Validation
      if (!mac || isNaN(handle) || !operation) {
        node.status({fill: "red", shape: "ring", text: "missing params"})
        return node.send([null, { payload: 'Missing parameter: mac, handle or operation' }, null])
      }

      if (operation === 'write' && (!data || data.length === 0)) {
        node.status({fill: "red", shape: "ring", text: "no data"})
        return node.send([null, { payload: 'Missing write data' }, null])
      }

      try {
        const result = await processBluetoothOperation(operation, handle, mac, data)
        node.status({fill: "green", shape: "dot", text: "done"})
        node.send(result)
      } catch (error) {
        node.status({fill: "red", shape: "dot", text: "error"})
        node.error(error.message)
        node.send([null, { payload: error.message }, null])
      }
    })
  }

  RED.nodes.registerType('ble', BluetoothNode)
}