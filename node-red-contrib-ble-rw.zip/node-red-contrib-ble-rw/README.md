# node-red-contrib-ble-rw

A Node-RED node for Bluetooth Low Energy (BLE) read and write operations, based on the `node-ble` library.

## Features
- **Hybrid Configuration**: Set MAC, Handle, and Operation in the node settings or override them via `msg.payload`.
- **Three Outputs**: 
  1. `stdout`: Success confirmation.
  2. `stderr`: Error messages.
  3. `return`: Raw hex data from read operations.

## Input Payload Format
You can trigger the node by sending a JSON object:
```json
{
    "operation": "write",
    "handle": "0x0074",
    "mac": "D8:71:4D:00:6D:3D",
    "data": "10000000"
}